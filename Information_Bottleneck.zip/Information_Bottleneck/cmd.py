import os

para="/Volumes/Macintosh\ HD\ -\ Data/Script/Information_Bottleneck/Script"
os.system(para)


#para_cmd="parallel --jobs 2 --delay 2 --progress"
#para_tar=" \"./runner\" {1} ::: 1 2"
#os.system(para_cmd+para_tar)